﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace RestWrapper
{
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    [ProgId("RestWrapper.RestHandler")]
    [Guid("A6B34F93-3FD6-4EAA-955F-017A6E8BEBC9")]
    [Serializable()]
    public class RestHandler
    {
        [ComVisible(true)]
        public dynamic Post(string postURL, object postBodyJson, string acceptType, string contentType, string certPath)
        {
            if (string.IsNullOrEmpty(acceptType)) acceptType = "application/json";
            if (string.IsNullOrEmpty(contentType)) contentType = "application/json";
            try
            {
                var client = new RestClient(postURL);
                if (!string.IsNullOrEmpty(certPath))
                {
                    client.ClientCertificates = loadClientCerts(certPath);                   
                }

                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                client.Proxy = new WebProxy();
                var restrequest = new RestRequest(Method.POST);
                restrequest.AddHeader("Cache-Control", "no-cache");
                restrequest.AddHeader("Accept", acceptType);
                restrequest.AddHeader("Content-Type", contentType);
                restrequest.AddParameter(
   contentType,
   postBodyJson, 
   ParameterType.RequestBody);
                restrequest.RequestFormat = DataFormat.Json;
                IRestResponse response = client.Post(restrequest);
                return response;

            }
            catch
            {
                throw;
            }
        }

        private X509CertificateCollection loadClientCerts(string certPath)
        {
            X509Store a =new X509Store("")
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;

            var certFile = Path.Combine(certPath);
            X509Certificate2 certificate = new X509Certificate2(certFile);
            return new X509CertificateCollection() { certificate };
        } 

        [ComVisible(true)]
        public dynamic Get(string getURL, string acceptType, string certLocation)
        {
            if (string.IsNullOrEmpty(acceptType)) acceptType = "application/json";
           // return "Com Visible Rest Caller Working - " + getURL + " " + acceptType;
            var client = new RestClient(getURL);
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            client.Proxy = new WebProxy();
            var restrequest = new RestRequest(Method.GET);
            restrequest.AddHeader("Cache-Control", "no-cache");
            restrequest.AddHeader("Accept", acceptType);
            var response = client.Execute(restrequest);
            return (dynamic)response;
        }

      /// <summary>
      /// 
      /// 
      /// </summary>
      /// <returns></returns>

        [ComVisible(true)]
        public string RestHandlerTest() {
            return "Com Visible Rest Caller Working";
        }
    }
}
